/*
 * Copyright (c) 2015, 2016 ARM Limited. All rights reserved.
 * SPDX-License-Identifier: Apache-2.0
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#define __STDC_FORMAT_MACROS
#include <inttypes.h>
#include <string>
#include <sstream>
#include <vector>

#include "mbed.h"

#include "security.h"
#include "mbed-trace/mbed_trace.h"
#include "mbedtls/entropy_poll.h"

#include "easy-connect/easy-connect.h"
#include "simpleclient.h"
#include "easy-resources.h"

RES res;

// These are example resource values for the Device Object
struct MbedClientDevice device = {
    "Manufacturer_String",      // Manufacturer
    "Type_String",              // Type
    "ModelNumber_String",       // ModelNumber
    "SerialNumber_String"       // SerialNumber
};

// Instantiate the class which implements LWM2M Client API (from simpleclient.h)
MbedClient mbed_client(device);
volatile bool registered = false;
osThreadId mainThread;

// Network interaction must be performed outside of interrupt context
//Semaphore updates_global(0);
EventFlags event_main;

Ticker updater;
volatile bool update = false;
void update_handle()	{ update = true; osSignalSet(mainThread, 0x1);} //event_main.set(0x1); }	//updates_global.release(); }

Ticker _updater;
bool update_flag;
void _update_handle()	{ update_flag = true; osSignalSet(mainThread, 0x1);}

	
void entropy_init() {
	
	unsigned int seed;
    size_t len;

	#ifdef MBEDTLS_ENTROPY_HARDWARE_ALT
		// Used to randomize source port
		mbedtls_hardware_poll(NULL, (unsigned char *) &seed, sizeof seed, &len);

	#elif defined MBEDTLS_TEST_NULL_ENTROPY

	#warning "mbedTLS security feature is disabled. Connection will not be secure !! Implement proper hardware entropy for your selected hardware."
		// Used to randomize source port
		mbedtls_null_entropy_poll( NULL,(unsigned char *) &seed, sizeof seed, &len);

	#else

	#error "This hardware does not have entropy, endpoint will not register to Connector.\
	You need to enable NULL ENTROPY for your application, but if this configuration change is made then no security is offered by mbed TLS.\
	Add MBEDTLS_NO_DEFAULT_ENTROPY_SOURCES and MBEDTLS_TEST_NULL_ENTROPY in mbed_app.json macros to register your endpoint."

	#endif

    srand(seed);
}

// Entry point to the program
int main() {
	
	printf("\nStarting mbed Client example\n");
	
	//**************************** easy-connect init ****************************//
	
	entropy_init();
	
	mbed_trace_init();

    NetworkInterface* network = easy_connect(true);
    if(network == NULL) {
        printf("\nConnection to Network Failed - exiting application...\n");
        return -1;
    }
	
    // Create endpoint interface to manage register and unregister
    mbed_client.create_interface(MBED_SERVER_ADDRESS, network);

    // Create Objects of varying types, see simpleclient.h for more details on implementation.
    M2MSecurity* register_object = mbed_client.create_register_object(); // server object specifying connector info
    M2MDevice*   device_object   = mbed_client.create_device_object();   // device resources object

    // Create list of Objects to register
    M2MObjectList object_list;

    // Add objects to list
    object_list.push_back(device_object);
	object_list.push_back(res.rgb->get_object());
	object_list.push_back(res.led->get_object());
	object_list.push_back(res.button->get_object());
	object_list.push_back(res.e_time->get_object());
	// Set endpoint registration object
    mbed_client.set_register_object(register_object);

    // Register with mbed Device Connector
    mbed_client.test_register(register_object, object_list);
    
	registered = true;
	
	//**************************************************************************//
	
	// Keep track of the main thread
    mainThread = osThreadGetId();
	
	res.mems->thread_enable();
	
	
	updater.attach(&update_handle,10.0);
	_updater.attach(_update_handle,1.0);
	
	while (true) {
		
		//Thread::wait(1000);
		osSignalWait(0x1, 1000); //osWaitForever
		
		if(res.button->clicked) {
			printf("\r\n------- Button Action -------\r\n");
			
			res.rgb->write(red,true);
			
			res.mems->update_sensors(ALL);
			
			printf("\n");
			res.button->clicked = false;
		}
		
		if(update_flag) {
			printf("\r\n------- MEMS Action -------\r\n");
			res.mems->update_sensors(ALL);
			printf("\n");
			update_flag = false;
		}
		
		if(update) {
			
			printf("\r\n------- A -------\r\n");
			
			update = false;
			
			//if(registered) {
			//	printf("\r\n------- B -------\r\n");
			//	mbed_client.test_update_register();
			//}
			
			printf("\r\n------- Update Action -------\r\n");
			
			res.e_time->mdc_update_value();
			res.rgb->write(green,false);
			
			printf("\n");
		}
		
	}
	
    mbed_client.test_unregister();
    updater.detach();
}


#ifndef __M_LED_H__
#define __M_LED_H__

#include "mbed.h"

#define CoAP_LED_OBJ	"2"
#define CoAP_LED_STATUS	"1"

#define OFF			0
#define ON 			1
#define INVALID 	-1

class LED: public DigitalOut
{
public:

	LED(PinName ledPin) : DigitalOut(ledPin) , status(false) {
		led_test(20);
		
		led_object = M2MInterfaceFactory::create_object(CoAP_LED_OBJ);
		M2MObjectInstance* led_inst = led_object->create_object_instance();
		
		M2MResource* res_status = led_inst->create_dynamic_resource(CoAP_LED_STATUS, "status",
				M2MResourceInstance::STRING, true /* observable */);
		res_status->set_operation(M2MBase::PUT_ALLOWED);
		res_status->set_value((uint8_t*)"off", 3);
		res_status->set_value_updated_function(value_updated_callback(this,&LED::status_updated));
	}
	
	void status_updated(const char* x) {
		printf("\n[LED::status_updated]: ");
		M2MObjectInstance* inst = led_object->object_instance();
		M2MResource* res = inst->resource(CoAP_LED_STATUS);
		
		String payload_M2M = res->get_value_string();
		string payload(payload_M2M.c_str());		// Convert from M2M String to std::string
		
		int8_t status_update = string_to_status(payload); 
		
		if(status_update != INVALID) {
			status = status_update;
			printf("status updated to: %s (%i)\n",payload.c_str(),status);
			this->write(status);
		} else {
			printf("invalid led status received: %s\n",payload.c_str());
		}
		
	};
	
	int8_t string_to_status(string led_status) {
		if(led_status.compare("on") == 0)
			return ON;
		else if(led_status.compare("off") == 0)
			return OFF;
		else
			return INVALID;
		
	}
	
	void led_test(char cycles){
		printf("\r\n********* led test *********\r\n");
		for(int i = 0; i < cycles; i++) {
			this->write(!(this->read()));
			wait(0.1);
		}
	}
	
	M2MObject* get_object() {
        return led_object;
    }
	
public:
	uint8_t status;
	M2MObject*  led_object;
};

#endif //__M_LED_H__
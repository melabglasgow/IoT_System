#ifndef __MEMS_H__
#define __MEMS_H__

#include "mbed.h"
#include "x_nucleo_iks01a1.h"

#define shift(bit) (1 << bit)

#define X	0
#define Y	1
#define Z	2

//extern EventFlags event_main;
extern osThreadId mainThread;

enum sensor{
	GYRO	= shift(0),
	ACCE	= shift(1),
	MAGN	= shift(2),
	HUMI	= shift(3),
	PRES	= shift(4),
	TEMP1	= shift(5),
	TEMP2	= shift(6),
	ALL		= 63,
};

class MEMS
{
public:
	MEMS(void)
	{	
		gyro = (int32_t*) malloc(3);
		acce = (int32_t*) malloc(3);
		magn = (int32_t*) malloc(3);
		
		humi = 0; pres = 0; temp1 = 0; temp2 = 0;
	
		mems_expansion_board = X_NUCLEO_IKS01A1::Instance(D14, D15);
		gyroscope = mems_expansion_board->GetGyroscope();
		accelerometer = mems_expansion_board->GetAccelerometer();
		magnetometer = mems_expansion_board->magnetometer;
		humidity_sensor = mems_expansion_board->ht_sensor;
		pressure_sensor = mems_expansion_board->pt_sensor;
		temp_sensor1 = mems_expansion_board->ht_sensor;
		temp_sensor2 = mems_expansion_board->pt_sensor;
		
		id();
		
	}

	void thread_enable(void) {
		
		this->thread = new Thread();
		// we have to wait until the main loop starts in the endpoint before we create our thread... 
		if (this->thread != NULL) {
			this->thread->start(callback(this,&MEMS::mems_thread));
	    }else {
			printf("thread is NULL!");
		}
		//_updater.attach(this,&MEMS::update_handle,1);
	}
	
	void update_sensors(int cmd) {
		_update = cmd;
        _event.set(0x3);
    }
	
	void mems_thread(void) {
        while (true) {
            _event.wait_all(0x3);
			_update_sensors();
        }
    }
	
	void _update_sensors() {
		if( (_update && TEMP1) != 0)
			temp_sensor1->get_temperature(&temp1);
		if( (_update && TEMP2) != 0)
			temp_sensor2->get_fahrenheit(&temp2);
		if( (_update && HUMI) != 0)
			humidity_sensor->get_humidity(&humi);
		if( (_update && PRES) != 0)
			pressure_sensor->get_pressure(&pres);
		if( (_update && MAGN) != 0)
			magnetometer->get_m_axes(magn);
		if( (_update && ACCE) != 0)
			accelerometer->get_x_axes(acce);
		if( (_update && GYRO) != 0)
			gyroscope->get_g_axes(gyro);
		//print();
	}
	
	void id() {
		uint8_t id;

		printf("\r\n********* mems test *********\r\n");
		humidity_sensor->read_id(&id);
		printf("HTS221  humidity & temperature    = 0x%X\r\n", id);
		pressure_sensor->read_id(&id);
		printf("LPS25H  pressure & temperature    = 0x%X\r\n", id);
		magnetometer->read_id(&id);
		printf("LIS3MDL magnetometer              = 0x%X\r\n", id);
		gyroscope->read_id(&id);
		printf("LSM6DS0 accelerometer & gyroscope = 0x%X\r\n", id);
	}
	
	void print() {
		printf("\r\n");
		printf("--------------- mems Values ---------------\r\n");
		printf("HTS221: [temp] %2.2f C,    [temp]  %2.2f F\r\n", temp1,temp2);
		printf("LPS25H: [hum]  %2.2f %%,    [press] %2.2f mbar\r\n", humi,pres);
		printf("---\r\n");
		printf("LSM6DS0 [gyro/mdps]:   %7ld, %7ld, %7ld\r\n", gyro[0], gyro[1], gyro[2]);
		printf("LSM6DS0 [acc/mg]:      %7ld, %7ld, %7ld\r\n", acce[0], acce[1], acce[2]);
		printf("LIS3MDL [mag/mgauss]:  %7ld, %7ld, %7ld\r\n", magn[0], magn[1], magn[2]);		
		printf("-------------------------------------------\r\n");
	}
	
public:	
	//bool update_flag;
private:
	X_NUCLEO_IKS01A1 *mems_expansion_board;
	Thread  *thread;
	int _update;
	EventFlags _event;
	//Ticker _updater;
	
	//void update_handle()	{ update_flag = true; osSignalSet(mainThread, 0x1);}

public:
	GyroSensor		*gyroscope;
	MotionSensor	*accelerometer;
	MagneticSensor	*magnetometer;
	HumiditySensor	*humidity_sensor;
	PressureSensor	*pressure_sensor;
	TempSensor		*temp_sensor1;
	TempSensor		*temp_sensor2;

public:
	int32_t *gyro;
	int32_t *acce;
	int32_t *magn;
	float humi, pres, temp1, temp2;
};

#endif //__MEMS_H__
#ifndef __EASY_RESOURCES_H__
#define __EASY_RESOURCES_H__

#include "mbed.h"

#include "rgb.h"
#include "mems.h"
#include "button_count.h"
#include "elapsed_time.h"
#include "m_led.h"

class RES
{
public:
	
	void available_resources(void) {
		printf("\n----------- Available Resource -----------\r\n");
		if(mems != NULL)
			printf("\t\t-->mems\r\n");
		if(rgb != NULL)
			printf("\t\t-->rgb\r\n");
		if(button != NULL)
			printf("\t\t-->button\r\n");
		if(led != NULL)
			printf("\t\t-->led\r\n");
		if(e_time != NULL)
			printf("\t\t-->timer\r\n");
			
	}
	
	RES(){
		
		#if MEMS_RESOURCE == true
			mems = new MEMS;
		#endif

		#if RGB_RESOURCE == true
			rgb = new RGB(PB_2,PB_15,PB_1); //RGB pins
		#endif

		#if BUTTON_RESOURCE == true
			button = new BUTTON(USER_BUTTON);
		#endif
		
		#if LED_RESOURCE == true
			led = new LED(LED1);
		#endif
		
		#if TIMER_RESOURCE == true
			e_time = new ELAPSED_T;
		#endif
		
		available_resources();
	}
	
public:
	MEMS *mems;
	RGB *rgb;
	BUTTON *button;
	LED *led;
	ELAPSED_T *e_time;
};


#endif //__EASY_RESOURCES_H__
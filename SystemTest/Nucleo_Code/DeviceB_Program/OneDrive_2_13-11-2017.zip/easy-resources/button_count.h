\
#ifndef __BUTTON_H__
#define __BUTTON_H__

#include "mbed.h"

#define CoAP_BUTTON_OBJ		"4"
#define CoAP_BUTTON_COUNT	"1"

//extern Semaphore updates_global;
//extern EventFlags event_main;
extern osThreadId mainThread;	//osSignalSet(mainThread, 0x1);

class BUTTON : public InterruptIn{
public:
    
	BUTTON(PinName pin) : InterruptIn(pin) , count(0) , clicked(false) {       							// create the InterruptIn on the pin specified to Counter
		this->fall(this, &BUTTON::callback); 								// attach increment function of this counter instance
		printf("\r\n********* Button Count Initialised *********\r\n");
		
		button_object = M2MInterfaceFactory::create_object(CoAP_BUTTON_OBJ);
		M2MObjectInstance* button_inst = button_object->create_object_instance();
		
		M2MResource* res_count = button_inst->create_dynamic_resource(CoAP_BUTTON_COUNT, "count",
			M2MResourceInstance::STRING, true /* observable */);
		res_count->set_operation(M2MBase::GET_ALLOWED);
		res_count->set_value((uint8_t*)"0", 1);
    }
	
	void mdc_update_count(){
		printf("[BUTTON::mdc_update_count]: ");
		
		M2MObjectInstance* inst = button_object->object_instance();
		M2MResource* res = inst->resource(CoAP_BUTTON_COUNT);
		
		// serialize the value of counter as a string, and tell connector
		char buffer[3];
		int size = sprintf (buffer, "%d", count);
		res->set_value((uint8_t*)buffer, size);
		printf("count updated to %i \n",count);
	}
	
    void callback() {
		printf("[BUTTON::callback]: clicked = true, count++, //updates_global.released\n");
		clicked = true;
        count++;
		mdc_update_count();
		//event_main.set(0x1);
		//updates_global.release();
		osSignalSet(mainThread, 0x1);
    }
		
	M2MObject* get_object() {
        return button_object;
    }
	
public:
	bool clicked;
	uint8_t count;
private:
	M2MObject*  button_object;
};

#endif //__BUTTON_H__
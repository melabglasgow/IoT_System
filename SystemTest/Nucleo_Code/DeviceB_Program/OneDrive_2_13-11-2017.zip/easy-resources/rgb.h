
#ifndef __RGB_H__
#define __RGB_H__

#include "mbed.h"

#define shift(bit) (1 << bit)
#define rgbAll rgb1 = rgb2 = rgb3

#define CoAP_RGB_OBJ	"1"
#define CoAP_RGB_INFO	"1"
#define CoAP_RGB_COLOR	"2"

//BusOut rgb1(PB_2,PB_15,PB_1);
//BusOut rgb2(PC_8,PC_5,PC_6);
//BusOut rgb3(PA_12,PB_12,PA_11);

enum color{
	no_color	= -1,
	red			= shift(0),
	green		= shift(1),
	blue		= shift(2),
	white		= 7,
	off			= 0
};

#include <functionpointer.h>

class RGB
{
public:

	RGB(PinName redpin, PinName bluepin, PinName greenpin){
		rgb = new BusOut(redpin,bluepin,greenpin);
		rgb_test(2);
		
		rgb_object = M2MInterfaceFactory::create_object(CoAP_RGB_OBJ);
		M2MObjectInstance* rgb_inst = rgb_object->create_object_instance();
		
		string info = "options: red, blue, green, white, off";
		M2MResource* res_info = rgb_inst->create_static_resource(CoAP_RGB_INFO, "info",
			M2MResourceInstance::STRING,(uint8_t*)info.c_str(), info.length());
		
		M2MResource* res_color = rgb_inst->create_dynamic_resource(CoAP_RGB_COLOR, "color",
		M2MResourceInstance::STRING, true /* observable */);
		res_color->set_operation(M2MBase::GET_PUT_ALLOWED);
		res_color->set_value((uint8_t*)"white",10);
		value_updated_callback value_updated_function;
		
		res_color->set_value_updated_function(value_updated_callback(this,&RGB::color_updated));
	}
	
	void color_updated(const char* x) {
		printf("\n[RGB::color_updated]: ");
		M2MObjectInstance* inst = rgb_object->object_instance();
		M2MResource* res = inst->resource(CoAP_RGB_COLOR);
		
		String payload_M2M = res->get_value_string();
		string payload(payload_M2M.c_str());		// Convert from M2M String to std::string
		
		color color_update = string_to_color(payload); 
		
		if(color_update != no_color) {
			printf("color updated to: %s (%i)\n",payload.c_str(),color_update);
			write(color_update,false);
		} else {
			printf("invalid rgb color received: %s\n",payload.c_str());
		}
		
	};

	void mdc_set_color(color led_color){
		printf("[RGB::mdc_set_color]: ");
		M2MObjectInstance* inst = rgb_object->object_instance();
		
		M2MResource* res = inst->resource(CoAP_RGB_COLOR);
				
		// serialize the value of counter as a string, and tell connector
		
		string str = color_to_string(led_color);
		char *cstr = new char[str.length()];
		strcpy(cstr, str.c_str());
		res->set_value((uint8_t*)cstr, str.length());
		printf("color set to %s \n",str.c_str());
		delete [] cstr;
	}
	
	void write(color led_color, bool mdc_update) {
		printf("[RGB::write]: ");
		status = led_color;
		*rgb = led_color;
		printf("color ID %i \n",led_color);
		if (true)									//if (mdc_update)
			mdc_set_color(led_color);
	}
	
	void rgb_test(char cycles){
		printf("\r\n********* rgb test *********\r\n");
		int rgb_counter = 0;
		int i = 0;
		while(i < cycles) {
			switch(rgb_counter){
				case 0:
					*rgb = red;
					break;
				case 1:
					*rgb = green;
					break;
				case 2:
					*rgb = blue;
					break;
				case 3:
					*rgb = white;
					break;
				case 4:
					*rgb = off;
					break;
				default:
					i++;
					break;
			}
			if(rgb_counter == 5)
				rgb_counter = 0;
			else
				rgb_counter++;
			wait(0.2);
		}	
	}
	
	string color_to_string(color led_color) {
		if(led_color == red)
			return "red";
		else if(led_color == green)
			return "green";
		else if(led_color == blue)
			return "blue";
		else if(led_color == white)
			return "white";
		else if(led_color == off)
			return "off";
		else
			return NULL;
	}
	
	color string_to_color(string led_color) {
		if(led_color.compare("red") == 0)
			return red;
		else if(led_color.compare("blue") == 0)
			return blue;
		else if(led_color.compare("green") == 0)
			return green;
		else if(led_color.compare("white") == 0)
			return white;
		else if(led_color.compare("off") == 0)
			return off;
		else
			return no_color;	
	}
	
	M2MObject* get_object() {
        return rgb_object;
    }
	
public:
	color status;
private:
	BusOut *rgb;
	M2MObject*  rgb_object;
};

#endif //__RGB_H__